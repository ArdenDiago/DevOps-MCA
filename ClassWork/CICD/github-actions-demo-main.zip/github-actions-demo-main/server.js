import app from "./app.js";

const port = 300;
app.listen(port, () => {
  console.log(`Server listening on port ${port}`);
});
